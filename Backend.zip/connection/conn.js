const mongoose=require("mongoose");
mongoose.connect("mongodb+srv://jheel0696be21:DnzaZhGBGOLQqJaX@cluster0.tgemhd7.mongodb.net/?retryWrites=true&w=majority")
.then(()=>console.log("Connected"));